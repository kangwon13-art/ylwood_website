/**
 * 영림우드 재단 최적화 엔진 v2
 * 수정: 양방향 배치 + 잔재 컷 기준 kerf + 전폭 전단 체크
 */

const KERF = 4.5;
const TRIM = 14;
const MIN_CUT = KERF; // 잔재가 kerf보다 크면 컷으로 셈

const SPECS = {
  '4x8': { w: 1220, l: 2440 },
  '3x6': { w: 910,  l: 1820 },
};

const PRICE = {
  low:  { d1: 500, d2: 700  },
  high: { d1: 700, d2: 1000 },
};

function getPriceTier(t) { return t <= 12 ? 'low' : 'high'; }

// ─── 스트립 패킹 (한 원장, 한 방향) ─────────────────
// packW = 스트립 내 조각 나열 방향의 유효 크기
// packL = 스트립 쌓는 방향의 유효 크기
function packSheet(pieces, packW, packL) {
  const strips = [];
  let y = 0;
  const avail = pieces.slice();

  while (avail.length > 0) {
    const sh = avail[0].pl; // 스트립 높이 = 첫 조각의 l 방향
    if (y + sh > packL + 0.01) break;

    const items = [];
    let x = 0;

    for (let i = 0; i < avail.length;) {
      const p = avail[i];
      const dx = (items.length > 0 ? KERF : 0) + p.pw;
      if (p.pl <= sh + 0.01 && x + dx <= packW + 0.01) {
        if (items.length > 0) x += KERF;
        items.push({ x, y, pw: p.pw, pl: p.pl, src: p });
        x += p.pw;
        avail.splice(i, 1);
      } else i++;
    }

    if (items.length === 0) break;
    strips.push({ y, h: sh, usedW: x, items });
    y += sh + KERF;
  }
  return { strips, unplaced: avail };
}

// ─── 전체 풀이 ──────────────────────────────────────
function solve(items, specKey, thickness, useTrim) {
  const spec = SPECS[specKey];
  const tier = getPriceTier(thickness);
  const rate = PRICE[tier];

  // 유효 치수
  const effW = spec.w - (useTrim ? TRIM : 0); // 상전단=폭줄임
  const effL_trimmed = spec.l - (useTrim ? TRIM : 0); // 좌전단=길이줄임
  const rawW = spec.w, rawL = spec.l;

  // 조각 전개
  const allPieces = [];
  const tooBig = [];
  items.forEach((it, idx) => {
    for (let i = 0; i < it.q; i++) {
      allPieces.push({ ow: it.w, ol: it.l, grain: it.g, idx });
    }
  });

  // 정렬 전략
  const sorts = [
    (a, b) => b.pl - a.pl || b.pw - a.pw,
    (a, b) => b.pw - a.pw || b.pl - a.pl,
    (a, b) => (b.pw * b.pl) - (a.pw * a.pl),
  ];

  let best = null;

  // 전략: 회전 여부 × 배치 방향(폭우선/길이우선) × 정렬
  [false, true].forEach(doRotate => {  // 조각 회전
    [false, true].forEach(swapAxis => {  // 배치 축 스왑
      sorts.forEach(sf => {

        // 조각 준비
        const pcs = [];
        allPieces.forEach(p => {
          let w = p.ow, l = p.ol;
          // 전폭(ow==rawW)·전길이(ol==rawL) 조각은 방향 고정 → 회전 금지
          const isOrigFW = (p.ow === rawW);
          const isOrigFL = (p.ol === rawL);
          if (doRotate && !p.grain && !isOrigFW && !isOrigFL) { w = p.ol; l = p.ow; }

          // 전폭/전길이 판정
          const isFullW = (w === rawW);
          const isFullL = (l === rawL);

          // 전폭 조각 + 전단 → w가 effW보다 크면 안 들어감
          if (useTrim && isFullW && w > effW + 0.01) {
            tooBig.push(p);
            return;
          }

          // 유효 길이: 전길이·전폭은 좌전단 생략 → rawL 사용
          const useL = (isFullL || isFullW) ? rawL : effL_trimmed;

          if (w > effW + 0.01 || l > useL + 0.01) {
            // 회전 안 된 원본도 시도
            if (!p.grain) {
              const w2 = p.ol, l2 = p.ow;
              const isFL2 = (l2 === rawL), isFW2 = (w2 === rawW);
              if (useTrim && isFW2 && w2 > effW + 0.01) return;
              const useL2 = (isFL2 || isFW2) ? rawL : effL_trimmed;
              if (w2 <= effW + 0.01 && l2 <= useL2 + 0.01) {
                pcs.push({ pw: w2, pl: l2, isFullW: isFW2, isFullL: isFL2, src: p });
                return;
              }
            }
            return; // 안 들어감
          }

          // 배치 축 스왑: pw/pl 교환 (패킹 내부 좌표)
          if (swapAxis) {
            pcs.push({ pw: l, pl: w, isFullW, isFullL, src: p, swapped: true });
          } else {
            pcs.push({ pw: w, pl: l, isFullW, isFullL, src: p, swapped: false });
          }
        });

        pcs.sort(sf);

        // 패킹
        const packW = swapAxis ? (effL_trimmed) : effW;
        // packL은 시트별로 조각 내용에 따라 결정
        const sheets = [];
        let rem = pcs.slice();
        let guard = 0;

        while (rem.length > 0 && guard++ < 200) {
          // 이 원장에서 전길이·전폭 조각 유무 → 유효길이 결정
          const anyFull = rem.some(p => p.isFullL || p.isFullW);
          let packL;
          if (swapAxis) {
            packL = effW; // 스왑 시 쌓는 방향 = 원래 폭
          } else {
            packL = anyFull ? rawL : effL_trimmed;
          }

          const res = packSheet(rem, packW, packL);
          if (res.strips.length === 0) break;

          const sheetItems = res.strips.flatMap(s => s.items);

          // 1D/2D 판정
          const allFL = sheetItems.every(it => it.src.isFullL);
          const allFW = sheetItems.every(it => it.src.isFullW);
          const is1D = allFL || allFW;

          // 컷 수 산정
          let cuts = 0;
          const actualEffL = anyFull ? rawL : effL_trimmed;

          // 전단
          if (useTrim) {
            cuts += 1; // 상전단 (항상)
            if (!allFL) cuts += 1; // 좌전단 (전길이만이 아닌 경우)
          }

          // 리핑 (스트립 내)
          res.strips.forEach(st => {
            cuts += st.items.length - 1; // 조각 사이
            const remW = packW - st.usedW;
            if (remW > MIN_CUT) cuts += 1; // 끝 잔재 트림
          });

          // 크로스컷 (스트립 사이)
          if (res.strips.length > 1) cuts += res.strips.length - 1;
          const topH = res.strips.reduce((a, s) => a + s.h + KERF, 0) - KERF;
          const remL = packL - topH;
          if (remL > MIN_CUT) cuts += 1; // 상단/하단 잔재

          const unitPrice = is1D ? rate.d1 : rate.d2;

          sheets.push({
            strips: res.strips,
            items: sheetItems,
            type: is1D ? '1D' : '2D',
            cuts,
            cost: cuts * unitPrice,
            unitPrice,
            swapped: swapAxis,
          });

          rem = res.unplaced;
        }

        // 평가
        const totalPlaced = sheets.reduce((a, s) => a + s.items.length, 0);
        const nSheets = sheets.length;
        const used = sheets.reduce((a, s) =>
          a + s.items.reduce((b, it) => b + it.pw * it.pl, 0), 0);
        const totalArea = nSheets * effW * effL_trimmed;
        const loss = totalArea > 0 ? (1 - used / totalArea) : 1;
        const totalCost = sheets.reduce((a, s) => a + s.cost, 0);

        if (!best ||
            totalPlaced > best.totalPlaced ||
            (totalPlaced === best.totalPlaced && nSheets < best.totalSheets) ||
            (totalPlaced === best.totalPlaced && nSheets === best.totalSheets && totalCost < best.totalCost) ||
            (totalPlaced === best.totalPlaced && nSheets === best.totalSheets && totalCost === best.totalCost && loss < best.lossRate)) {
          best = {
            sheets, totalPlaced, totalSheets: nSheets, lossRate: loss,
            totalCuts: sheets.reduce((a, s) => a + s.cuts, 0),
            totalCost,
            cuts1D: sheets.filter(s => s.type === '1D').reduce((a, s) => a + s.cuts, 0),
            cuts2D: sheets.filter(s => s.type === '2D').reduce((a, s) => a + s.cuts, 0),
            sheets1D: sheets.filter(s => s.type === '1D').length,
            sheets2D: sheets.filter(s => s.type === '2D').length,
            tooBig: [], tier, rate,
          };
        }
      });
    });
  });

  if (!best) best = { sheets:[], totalPlaced:0, totalSheets:0, lossRate:1, totalCuts:0, totalCost:0, cuts1D:0, cuts2D:0, sheets1D:0, sheets2D:0, tooBig: allPieces, tier, rate };

  return best;
}

// ─── 테스트 ──────────────────────────────────────────
function test(name, items, specKey, thickness, useTrim, expect) {
  const r = solve(items, specKey, thickness, useTrim);
  const checks = [];
  if (expect.sheets !== undefined) checks.push(r.totalSheets === expect.sheets ? '✅' : `❌sheets=${r.totalSheets}≠${expect.sheets}`);
  if (expect.cuts !== undefined) checks.push(r.totalCuts === expect.cuts ? '✅' : `❌cuts=${r.totalCuts}≠${expect.cuts}`);
  if (expect.type) {
    const actual = r.sheets2D === 0 ? '1D' : (r.sheets1D === 0 ? '2D' : 'mixed');
    checks.push(actual === expect.type ? '✅' : `❌type=${actual}≠${expect.type}`);
  }
  const pass = checks.every(c => c === '✅');
  console.log(`${pass?'✅':'❌'} ${name}`);
  console.log(`   원장 ${r.totalSheets}장 | 컷 ${r.totalCuts}회 (1D:${r.cuts1D} 2D:${r.cuts2D}) | 재단비 ${r.totalCost.toLocaleString()}원 | 로스 ${(r.lossRate*100).toFixed(1)}%`);
  if (!pass) console.log(`   → ${checks.filter(c=>c!=='✅').join(', ')}`);
  return pass;
}

console.log('=== 재단 엔진 v2 테스트 ===\n');

test('1: 500×1200×4+400×1200×1 (전단X) → 1장,2D',
  [{w:500,l:1200,q:4,g:false},{w:400,l:1200,q:1,g:false}],
  '4x8',18,false, {sheets:1, type:'2D'});

test('2: 500×1200×4+400×1200×1 (전단O) → 1장,2D,8컷',
  [{w:500,l:1200,q:4,g:false},{w:400,l:1200,q:1,g:false}],
  '4x8',18,true, {sheets:1, type:'2D', cuts:8});

test('3: 60×2440×15 (전단O) → 1D',
  [{w:60,l:2440,q:15,g:false}],
  '4x8',18,true, {type:'1D'});

test('4: 1220×300×3 (전단X) → 1장,1D,3컷',
  [{w:1220,l:300,q:3,g:false}],
  '4x8',18,false, {sheets:1, type:'1D', cuts:3});

test('5: 1220×300×3 (전단O) → 전폭>유효폭, 0장',
  [{w:1220,l:300,q:3,g:false}],
  '4x8',18,true, {sheets:0});

test('6: 500×1200×2 (전단X) → 1장,2D',
  [{w:500,l:1200,q:2,g:false}],
  '4x8',18,false, {sheets:1, type:'2D'});

test('7: 300×600×4 (9T) → 2D, 12mm이하 단가',
  [{w:300,l:600,q:4,g:false}],
  '4x8',9,false, {type:'2D'});

test('8: 500×1200×4 결지킴 (전단X)',
  [{w:500,l:1200,q:4,g:true}],
  '4x8',18,false, {sheets:1});

test('9: 1206×300×3 (전단O) → 1206≠rawW이므로 2D',
  [{w:1206,l:300,q:3,g:false}],
  '4x8',18,true, {sheets:1, type:'2D'});
